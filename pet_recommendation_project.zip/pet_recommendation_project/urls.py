# pet_recommendation_project/urls.py

from django.contrib import admin
from django.urls import path
from pet_recommendation_app.views import recommend_pet, show_pet_recommendation_page

urlpatterns = [
    path('admin/', admin.site.urls),
    path('recommend_pet/', recommend_pet, name='recommend_pet'),  # 用于获取推荐宠物的数据
    path('show_recommendation/', show_pet_recommendation_page, name='show_recommendation'),  # 用于显示宠物推荐系统的页面
    # 如果还有其他视图或应用，请在这里继续添加路径。
]
