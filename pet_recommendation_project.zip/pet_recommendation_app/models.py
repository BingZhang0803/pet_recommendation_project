# pet_recommendation_app/models.py

from django.db import models

class Pet(models.Model):
    CATEGORY_CHOICES = [
        ('Dog', 'Dog'),
        ('Cat', 'Cat'),
        ('Bird', 'Bird'),
        ('Small Mammal', 'Small Mammal'),
        ('Reptile', 'Reptile'),
    ]
    
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    breed = models.CharField(max_length=100)
    traits = models.TextField()
    sociability = models.CharField(max_length=50)
    economic_investment = models.CharField(max_length=50)
    
    def __str__(self):
        return self.breed
