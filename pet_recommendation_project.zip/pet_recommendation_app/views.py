# pet_recommendation_app/views.py

from django.http import JsonResponse
from .models import Pet
from django.shortcuts import render
def recommend_pet(request):
    category = request.GET.get('category')  # 获取类别
    sociability = request.GET.get('sociability')  # 获取社交能力级别

    pets = Pet.objects.all()

    if category:
        pets = pets.filter(category=category)
    if sociability:
        pets = pets.filter(sociability=sociability)

    pets_list = list(pets.values('breed', 'category', 'sociability'))

    return JsonResponse(pets_list, safe=False)


def show_pet_recommendation_page(request):
    return render(request, 'pet_recommendation_template.html')

