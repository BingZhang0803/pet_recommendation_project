from django.db import migrations

def add_pet_data(apps, schema_editor):
    Pet = apps.get_model('pet_recommendation_app', 'Pet')
    pet_data = [
    {'category': 'Dog', 'breed': 'Labrador Retriever', 'traits': 'Friendly, loyal, needs regular exercise', 'sociability': 'High', 'economic_investment': 'Vet costs, food, training'},
    {'category': 'Dog', 'breed': 'French Bulldog', 'traits': 'Adapts well to city life, dependent on humans', 'sociability': 'Medium to High', 'economic_investment': 'Grooming and skin care costs'},
    {'category': 'Dog', 'breed': 'German Shepherd', 'traits': 'Intelligent, needs a lot of exercise', 'sociability': 'High', 'economic_investment': 'High vet costs, food costs'},
    {'category': 'Dog', 'breed': 'Poodle', 'traits': 'Smart, lively, good for allergy sufferers', 'sociability': 'High', 'economic_investment': 'Regular grooming costs'},
    {'category': 'Dog', 'breed': 'Akita', 'traits': 'Loyal, independent', 'sociability': 'Medium', 'economic_investment': 'Professional training and socialization'},
    {'category': 'Cat', 'breed': 'Siamese', 'traits': 'Loves to interact with people', 'sociability': 'High', 'economic_investment': 'Regular grooming, interactive toys'},
    {'category': 'Cat', 'breed': 'Persian', 'traits': 'Quiet, gentle', 'sociability': 'Low to Medium', 'economic_investment': 'Daily grooming costs'},
    {'category': 'Cat', 'breed': 'Burmese', 'traits': 'Outgoing personality, loves to play', 'sociability': 'High', 'economic_investment': 'Toys and scratching posts'},
    {'category': 'Cat', 'breed': 'British Shorthair', 'traits': 'Mild temperament', 'sociability': 'Medium', 'economic_investment': 'Basic care and health check costs'},
    {'category': 'Cat', 'breed': 'Bengal', 'traits': 'Intelligent, curious', 'sociability': 'High', 'economic_investment': 'Providing a safe environment and health checks'},
    {'category': 'Bird', 'breed': 'Parrot', 'traits': 'Can learn to talk and perform tricks', 'sociability': 'High', 'economic_investment': 'Food, cage, toys, vet costs'},
    {'category': 'Bird', 'breed': 'Canary', 'traits': 'Melodious singing', 'sociability': 'Low', 'economic_investment': 'Cage and regular cleaning costs'},
    {'category': 'Bird', 'breed': 'Dove', 'traits': 'Generally gentle', 'sociability': 'Low', 'economic_investment': 'Housing and feeding costs'},
    {'category': 'Small Mammal', 'breed': 'Dutch Dwarf Rabbit', 'traits': 'Docile', 'sociability': 'Medium', 'economic_investment': 'Cage, feed, health check costs'},
    {'category': 'Small Mammal', 'breed': 'Hamster', 'traits': 'Nocturnal, easy to care for', 'sociability': 'Low', 'economic_investment': 'Cage and cleaning costs'},
    {'category': 'Small Mammal', 'breed': 'Chinchilla', 'traits': 'Active at night', 'sociability': 'Medium', 'economic_investment': 'Large cage and sand bath costs'},
    {'category': 'Small Mammal', 'breed': 'Guinea Pig', 'traits': 'Social', 'sociability': 'High', 'economic_investment': 'Feed and vitamin C supplementation costs'},
    {'category': 'Reptile', 'breed': 'Leopard Gecko', 'traits': 'Needs specific environmental conditions', 'sociability': 'Low', 'economic_investment': 'Environmental control equipment costs'},
    {'category': 'Reptile', 'breed': 'Red-Eared Slider', 'traits': 'Needs a large aquarium', 'sociability': 'Low', 'economic_investment': 'Aquarium, UV lamp'},
]

    for pet in pet_data:
        Pet.objects.create(**pet)

class Migration(migrations.Migration):

    dependencies = [
        ('pet_recommendation_app', '0001_initial'),  # 请将这里的'previous_migration_file'替换为上一次迁移的文件名
    ]

    operations = [
        migrations.RunPython(add_pet_data),
    ]
